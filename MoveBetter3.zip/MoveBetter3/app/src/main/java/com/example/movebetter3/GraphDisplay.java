package com.example.movebetter3;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class GraphDisplay {
    private Context context;
    private GraphView graphView;
    private LineGraphSeries<DataPoint> series;

    public GraphDisplay(Context context, GraphView graphView) {
        this.context = context;
        this.graphView = graphView;
        series = new LineGraphSeries<>();
        series.setColor(Color.BLUE);
        graphView.addSeries(series);
        graphView.getViewport().setYAxisBoundsManual(true);
        graphView.getViewport().setMinY(0);
        graphView.getViewport().setMaxY(10); // Change the value based on your requirement
    }

    public void addDataPoint(double x, double y) {
        series.appendData(new DataPoint(x, y), true, 100);
    }

    public void clearData() {
        series.resetData(new DataPoint[]{});
    }
}
